var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__cc84ab1e._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.m(20222)
R.m(46112)
module.exports=R.m(46112).exports
