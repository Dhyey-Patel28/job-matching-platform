var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/employers/route.js")
R.c("server/chunks/[root-of-the-server]__379c2af9._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.m(52734)
R.m(9760)
module.exports=R.m(9760).exports
