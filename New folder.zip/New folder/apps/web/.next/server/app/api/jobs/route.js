var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/jobs/route.js")
R.c("server/chunks/[root-of-the-server]__1df71fe9._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.m(95949)
R.m(51036)
module.exports=R.m(51036).exports
