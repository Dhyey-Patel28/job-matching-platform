var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/forgot-password/route.js")
R.c("server/chunks/[root-of-the-server]__a362d4f1._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.m(8781)
R.m(68915)
module.exports=R.m(68915).exports
