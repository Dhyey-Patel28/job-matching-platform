var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/candidates/route.js")
R.c("server/chunks/[root-of-the-server]__a357d442._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.m(26899)
R.m(71624)
module.exports=R.m(71624).exports
