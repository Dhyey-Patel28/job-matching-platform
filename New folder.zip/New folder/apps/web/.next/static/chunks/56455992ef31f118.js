__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/ea429803a16ebb81.js",
  "static/chunks/turbopack-44512ca5cdd68229.js"
])
