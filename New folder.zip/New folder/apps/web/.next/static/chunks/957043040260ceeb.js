__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/ea429803a16ebb81.js",
  "static/chunks/turbopack-423e528c26e0ad79.js"
])
