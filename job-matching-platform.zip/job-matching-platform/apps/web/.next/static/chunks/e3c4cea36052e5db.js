__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/d5a517ecd389044b.js",
  "static/chunks/turbopack-85805ad2b8de847f.js"
])
