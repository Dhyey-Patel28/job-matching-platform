globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/d5a517ecd389044b.js",
      "static/chunks/turbopack-85805ad2b8de847f.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/d5a517ecd389044b.js",
      "static/chunks/turbopack-08d403a4d7e903cb.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c62b4372c26b460f.js",
    "static/chunks/0c853e819ea6cacb.js",
    "static/chunks/7880f8283a6f3daf.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-dfe5d16951adb681.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];