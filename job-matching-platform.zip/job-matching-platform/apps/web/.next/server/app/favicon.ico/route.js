var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__2bebcdc4._.js")
R.c("server/chunks/node_modules_next_dist_77fd8386._.js")
R.c("server/chunks/node_modules_next_dist_03a3c8f9._.js")
R.c("server/chunks/node_modules_next_d5897c41._.js")
R.m(45075)
R.m(97346)
module.exports=R.m(97346).exports
