var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/profile/route.js")
R.c("server/chunks/[root-of-the-server]__aa80775f._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.m(79278)
R.m(78581)
module.exports=R.m(78581).exports
