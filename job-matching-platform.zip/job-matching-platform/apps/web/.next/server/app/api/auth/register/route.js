var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__2be43902._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.m(27915)
R.m(99262)
module.exports=R.m(99262).exports
