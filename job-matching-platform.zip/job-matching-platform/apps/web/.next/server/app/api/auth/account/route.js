var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/account/route.js")
R.c("server/chunks/[root-of-the-server]__e036d78d._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.m(92400)
R.m(29320)
module.exports=R.m(29320).exports
