var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/reset-password/route.js")
R.c("server/chunks/[root-of-the-server]__9c9a6c26._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.m(61769)
R.m(44337)
module.exports=R.m(44337).exports
